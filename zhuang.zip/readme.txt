This is a notebook with the different function for the min hashing
You can run each cell that has a markdown describing what the cell is supposed to do
Lib used is 
sympy
numpy
pip install numpy
pip install sympy